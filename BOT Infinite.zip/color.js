const Discord = require("discord.js")

module.exports.purple = "#800080"
