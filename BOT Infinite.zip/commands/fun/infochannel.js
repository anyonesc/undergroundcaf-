const Discord = require('discord.js');
const moment = require('moment'); 
moment.locale('pt-BR');

exports.run = (bot, message, args) => {

    
    

    let embed = new Discord.RichEmbed()

    let gAvatar = message.guild.iconURL

    let topicSemNada = 'Não definido.';
    let topic = message.channel.topic || topicSemNada;

    let nsfwnao = 'Não <a:negada:637061409221509132>';
    let nsfwsim = 'Sim <a:aceita:637061354599219211>';
    let nsfw = message.channel.nsfw ? nsfwsim : nsfwnao;
  
    embed.setTitle(` Informações do canal: #` + message.channel.name.toString())
    embed.setDescription(`<a:aceita:637061354599219211> **ID do discord**\n• ${message.channel.id}\n<a:aceita:637061354599219211>**Menção do canal**\n• ${message.channel}\n<a:aceita:637061354599219211> **Tópico do canal**\n• ${topic}\n<a:aceita:637061354599219211> **Guild**\n• ${message.guild.name}\n⚠️ **NSFW**\n• ${nsfw}`)
    embed.addField('<a:aceita:637061354599219211> **Canal criado há**', moment(message.channel.createdAt).format('LLL'))
    embed.setFooter('Rede Infinite - Network')
    embed.setThumbnail('https://cdn.discordapp.com/emojis/646064870642679812.png?v=1')
    embed.setColor("RANDOM")

    message.channel.send(embed);
}
 
module.exports.help = {
    name: "infochannel"
}