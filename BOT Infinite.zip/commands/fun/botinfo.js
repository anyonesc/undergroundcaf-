/**
 * Criado por SrDeDo_
 * Name: KeelTa
 * Version: 1.0.0
 * Modificação: 24/10/2019 - 00/16
 */

const Discord = require('discord.js');
const moment = require('moment');
moment.locale('pt-BR');

exports.run = (bot, message, args) => {
    let embed = new Discord.RichEmbed()
message.delete(0);
    embed.setTitle(`<:vailogo:631677918375837697> Informações da Rede Infinite`)
    embed.addField(`Nome:`, `❣ Infinite`, true)
    embed.addField(`<:super_keelta:636768010417340427> Usuários:`, ` ${bot.users.size}`, true)
    embed.addField(` Canais:`, `<:vailogo:631677918375837697> ${bot.channels.size}`, true)
    embed.addField(`<:alert_keelta:636768398042464310> Servidores:`, `${bot.guilds.size}`, true)
    embed.addField(`País:`, `:flag_br: Brazil`)
    embed.setFooter('Rede Infinite - Network', "https://images-ext-1.discordapp.net/external/iO5KlC8vLfnj6qNxlElgwT5VYC_I1Y7KeK_ft5mU1GY/%3Fsize%3D2048/https/cdn.discordapp.com/avatars/627704612857839629/bf7034526da28c7d3c8fbf4f0af98a3e.png?width=480&height=480")
    embed.setThumbnail('https://cdn.discordapp.com/avatars/627704612857839629/bf7034526da28c7d3c8fbf4f0af98a3e.png?size=2048')
    embed.setTimestamp()
    embed.setColor("RANDOM")

    message.channel.send(embed);
}

module.exports.help = {
    name: "botinfo"
}
